<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * @author Adriano_2
 */
require_once (str_replace('\\', '/', dirname(__FILE__)) . '/../pQry.php'); 

ini_set('include_path', ini_get('include_path').PATH_SEPARATOR.'C:/php/PEAR/PHPUnit');

?>
