<?php

/*
 * Include all files
 */

require_once 'pQryCore.php';
require_once 'pQryTag.php';
require_once 'pQryObj.php';
require_once 'pQryHTML.php';
require_once 'pQryEmpty.php';
require_once 'HTMLParser.php';

libxml_use_internal_errors(true);